
from itertools import cycle


f = open("/Users/xiaodugame/Downloads/jquery-2.1.1.min.js", "r")
fw = open("/Users/xiaodugame/Downloads/jquery-2.1.1.min.js.cr", "wb")

df = open("/Users/xiaodugame/Documents/work/code/game-files/game-list.json", "rb")
dfw = open("/Users/xiaodugame/Documents/work/code/game-files/game-list.json.df", "wb")

# 加密
byte = bytes(f.read(), 'utf-8')
key = [9]

myBytes = [a[0] for (a) in zip(byte)]
print(myBytes)

encrypted = [a ^ b for (a, b) in zip(byte, cycle(key))]
print(encrypted)
fw.write(bytes(encrypted))

# 解密

byte = bytes(df.read())
decrypted = [a ^ b for (a, b) in zip(byte, cycle(key))]


dfw.write(bytes(decrypted))
